# Responsive-Header
Responsive Header designed by using HTML and CSS media queries only.

This is a responsive Header design for websites created by using HTML and CSS only. Media Queries are added in css file to style different layouts of footer design.
JavaScript Code is added to perform some actions on small layouts in header hamburger and search icon.

* New additions from your side are always welcomed.
* Support for more designs and projects like these.